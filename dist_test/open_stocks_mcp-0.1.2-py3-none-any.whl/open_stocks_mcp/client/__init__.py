from open_stocks_mcp.client.app import main

__all__ = ["main"]
