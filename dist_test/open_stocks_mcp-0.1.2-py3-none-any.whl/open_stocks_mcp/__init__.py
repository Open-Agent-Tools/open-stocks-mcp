"""Open Stocks MCP - MCP Server for stock market data via Robin Stocks."""

__version__ = "0.1.2"
__author__ = "Wes Etheredge"
__email__ = "jwesleye@gmail.com"
__all__ = ["__version__"]
